## Firebase Configuration

For security reasons, the Firebase configuration file is not included in version control. To set up the project:

1. Copy `src/firebase/config.template.js` to `src/firebase/config.js`
2. Replace the placeholder values in `config.js` with your Firebase project credentials
3. Never commit `config.js` to version control 